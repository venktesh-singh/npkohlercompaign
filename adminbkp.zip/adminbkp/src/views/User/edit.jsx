import React from 'react';

function UserUpdate() {
  return (
    <>
      <h1>User Ram User Detail</h1>
    </>
  );
}

export default UserUpdate;
