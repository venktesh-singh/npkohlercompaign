export const BASE_URL = '/app/dashboard/default';
export const BASE_TITLE = ' | Datta Able Premium React Hooks + Redux Admin Template';

export const CONFIG = {
  layout: 'vertical',
  collapseMenu: false,
  layoutType: 'menu-dark'
};
